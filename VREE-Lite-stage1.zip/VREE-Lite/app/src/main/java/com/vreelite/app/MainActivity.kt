package com.vreelite.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF100B1C)
private val Panel = Color(0xFF211633)
private val Purple = Color(0xFF9B6DFF)
private val Muted = Color(0xFFB9AEC9)
private val White = Color(0xFFF8F4FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VreeLiteApp() }
    }
}

@Composable
fun VreeLiteApp() {
    var selectedTab by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            message = null
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple,
            background = Bg,
            surface = Panel,
            onBackground = White,
            onSurface = White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF191126)) {
                    val items = listOf("Beranda", "Negara", "Riwayat", "Profil")
                    val icons = listOf(Icons.Default.Home, Icons.Default.Public, Icons.Default.History, Icons.Default.Person)
                    items.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = { Icon(icons[index], contentDescription = label) },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Purple,
                                selectedTextColor = Purple,
                                indicatorColor = Color(0xFF382451),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when (selectedTab) {
                0 -> HomeScreen(Modifier.padding(padding), onAction = { message = it })
                1 -> CountriesScreen(Modifier.padding(padding), onAction = { message = it })
                2 -> HistoryScreen(Modifier.padding(padding))
                else -> ProfileScreen(Modifier.padding(padding), onAction = { message = it })
            }
        }
    }
}

@Composable
private fun HomeScreen(modifier: Modifier = Modifier, onAction: (String) -> Unit) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("VREE LITE", color = Purple, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                    Text("Halo! Selamat datang 👋", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Pusat layanan nomor virtual resmi", color = Muted, fontSize = 13.sp)
                }
                Box(
                    Modifier.size(44.dp).background(Panel, CircleShape),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.NotificationsNone, null, tint = White) }
            }
        }
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    Modifier.background(Brush.linearGradient(listOf(Color(0xFF6E3FC5), Color(0xFF30204D))))
                        .fillMaxWidth().padding(22.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("DOMPET AKUN", color = Color(0xFFE7D9FF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Rp 0", color = White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Saldo contoh — belum terhubung ke pembayaran", color = Color(0xFFE0D4F2), fontSize = 11.sp)
                        OutlinedButton(onClick = { onAction("Fitur saldo akan dibuat pada tahap berikutnya.") }) {
                            Text("Lihat detail saldo", color = White)
                        }
                    }
                }
            }
        }
        item {
            Text("Akses cepat", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickAction("Pilih negara", Icons.Default.Public, Modifier.weight(1f)) {
                    onAction("Buka tab Negara untuk melihat pilihan negara.")
                }
                QuickAction("Riwayat", Icons.Default.History, Modifier.weight(1f)) {
                    onAction("Riwayat akan muncul setelah layanan resmi terhubung.")
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VerifiedUser, null, tint = Purple)
                        Spacer(Modifier.width(8.dp))
                        Text("Penggunaan yang aman", color = White, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        "Gunakan nomor virtual hanya dari penyedia resmi dan sesuai ketentuan layanan. Jangan gunakan untuk mengambil alih akun atau menerima kode milik orang lain.",
                        color = Muted, fontSize = 12.sp, lineHeight = 18.sp
                    )
                }
            }
        }
        item {
            Text("Status pengembangan", color = White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            StatusRow("Tampilan dashboard", "Selesai", true)
            StatusRow("Pemilihan negara", "Demo", false)
            StatusRow("Login & penyedia nomor", "Belum dibuat", false)
        }
    }
}

@Composable
private fun QuickAction(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(icon, null, tint = Purple, modifier = Modifier.size(26.dp))
            Text(title, color = White, fontWeight = FontWeight.SemiBold)
            Text("Buka", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun CountriesScreen(modifier: Modifier = Modifier, onAction: (String) -> Unit) {
    val countries = listOf("🇮🇩  Indonesia", "🇺🇸  Amerika Serikat", "🇬🇧  Inggris", "🇨🇦  Kanada", "🇦🇺  Australia")
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Pilih negara", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Daftar contoh untuk desain. Ketersediaan nomor belum terhubung.", color = Muted, fontSize = 13.sp)
        countries.forEach { country ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onAction("$country dipilih. Integrasi provider akan ditambahkan nanti.") },
                colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(country, color = White, modifier = Modifier.weight(1f), fontSize = 15.sp)
                    Icon(Icons.Default.ChevronRight, null, tint = Muted)
                }
            }
        }
    }
}

@Composable
private fun HistoryScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Riwayat aktivitas", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Belum ada aktivitas", color = Muted)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
            Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, null, tint = Purple)
                Spacer(Modifier.width(12.dp))
                Text("Riwayat akan tercatat setelah akun dan layanan resmi tersedia.", color = Muted, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun ProfileScreen(modifier: Modifier = Modifier, onAction: (String) -> Unit) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Profil", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountCircle, null, tint = Purple, modifier = Modifier.size(42.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Pengunjung", color = White, fontWeight = FontWeight.Bold)
                    Text("Belum login", color = Muted, fontSize = 12.sp)
                }
            }
        }
        listOf("Masuk / Daftar", "Pusat bantuan", "Kebijakan privasi", "Tentang VREE Lite").forEach { label ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onAction("$label akan tersedia pada tahap berikutnya.") },
                colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(label, color = White, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.ChevronRight, null, tint = Muted)
                }
            }
        }
    }
}

@Composable
private fun StatusRow(title: String, status: String, done: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (done) Icons.Default.CheckCircle else Icons.Default.Schedule, null, tint = if (done) Color(0xFF65D6A1) else Purple)
        Spacer(Modifier.width(10.dp))
        Text(title, color = White, modifier = Modifier.weight(1f), fontSize = 13.sp)
        Text(status, color = Muted, fontSize = 11.sp)
    }
}
