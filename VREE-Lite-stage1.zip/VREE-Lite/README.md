# VREE Lite — Tahap 1

Starter Android app dengan Kotlin + Jetpack Compose dan tema dark purple.

## Isi tahap 1
- Dashboard awal
- Tab Beranda, Negara, Riwayat, Profil
- Daftar negara contoh
- Status pengembangan
- Belum ada login, pembayaran, layanan nomor, atau OTP. Semua data yang terlihat adalah contoh UI.

## Build APK melalui GitHub Actions (HP Android)
1. Buat repository GitHub baru bernama `VREE-Lite`.
2. Ekstrak ZIP ini, lalu unggah **isi folder** ke root repository (bukan folder ZIP-nya).
3. Buka tab **Actions** dan jalankan workflow `Build Android APK`.
4. Setelah workflow selesai dengan centang hijau, buka hasil run dan unduh artifact `VREE-Lite-debug-apk`.
5. Ekstrak artifact ZIP untuk mendapatkan `app-debug.apk`.

## Build lokal
Gunakan Android Studio dengan JDK 17 dan Gradle 8.11.1:
`gradle assembleDebug`

APK debug akan berada di:
`app/build/outputs/apk/debug/app-debug.apk`

## Catatan
Aplikasi ini hanya fondasi UI. Integrasi layanan nomor harus menggunakan provider resmi, mematuhi ketentuan provider dan hukum setempat, serta tidak digunakan untuk mengakses akun atau kode verifikasi milik orang lain.
